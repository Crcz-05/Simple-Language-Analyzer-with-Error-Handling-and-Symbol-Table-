#include<stdio.h>
void main(){
    int a=2,b=4,c;
    c=a-b;
    printf("%d",c);
}