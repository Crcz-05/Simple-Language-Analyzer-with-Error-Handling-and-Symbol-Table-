#include<stdio.h>
void main(){
    int a=2,b=4;
    int a=5;
}